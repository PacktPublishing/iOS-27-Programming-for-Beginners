//
//  JournalEntryDetailViewController.swift
//  JRNL
//
//  Created by ios26programming on 04/11/2025.
//

import UIKit
import MapKit

class JournalEntryDetailViewController: UITableViewController {
    // MARK: - Properties
    @IBOutlet var dateLabel: UILabel!
    @IBOutlet var titleLabel: UILabel!
    @IBOutlet var bodyTextView: UITextView!
    @IBOutlet var photoImageView: UIImageView!
    @IBOutlet var mapImageView: UIImageView!
    @IBOutlet var ratingView: RatingView!
    
    var selectedJournalEntry: JournalEntry?

    override func viewDidLoad() {
        super.viewDidLoad()
        dateLabel.text = selectedJournalEntry?.date.formatted(
            .dateTime.day().month(.wide).year()
        )
        ratingView.rating = selectedJournalEntry?.rating ?? 0
        titleLabel.text = selectedJournalEntry?.entryTitle
        textViewDataToText(textViewData: selectedJournalEntry?.body)
        if let photoData = selectedJournalEntry?.photoData {
            photoImageView.image = UIImage(data: photoData)
        } else {
            photoImageView.image = nil
        }
        getMapSnapshot()
    }
    
    // MARK: - Private methods
    private func getMapSnapshot() {
        guard let lat = selectedJournalEntry?.latitude, let long = selectedJournalEntry?.longitude else {
            mapImageView.image = nil
            return
        }
        let options = MKMapSnapshotter.Options()
        options.region = MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: lat, longitude: long), span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01))
        options.size = CGSize(width: 300, height: 300)
        options.preferredConfiguration = MKStandardMapConfiguration()
        let snapshotter = MKMapSnapshotter(options: options)
        snapshotter.start { snapshot, error in
            if let snapshot {
                self.mapImageView.image = snapshot.image
            } else if let error {
                print("snapshot error: \(error.localizedDescription)")
            }
        }
    }
    
    private func textViewDataToText(textViewData: Data?) {
        if let textViewData {
            do {
                let textFromData = try NSAttributedString(data: textViewData, documentAttributes: nil)
                bodyTextView.textStorage.setAttributedString(textFromData)
            } catch {
                print("Error converting data to attributed string")
            }
        }
    }

 
}
