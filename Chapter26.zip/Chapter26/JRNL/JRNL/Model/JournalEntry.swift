//
//  JournalEntry.swift
//  JRNL
//
//  Created by ios26programming on 03/11/2025.
//

import UIKit
import MapKit

class JournalEntry: NSObject, MKAnnotation, Codable {
    // MARK: - Properties
    var key = UUID().uuidString
    let date: Date
    let rating: Int
    let entryTitle: String
    let body: Data
    let photoData: Data?
    let latitude: Double?
    let longitude: Double?
    
    // MARK: - Initialization
    init?(rating: Int, title: String, body: Data, photo: UIImage? = nil, latitude: Double? = nil, longitude: Double? = nil) {
        if title.isEmpty || body.isEmpty || rating < 0 || rating > 5 {
            return nil
        }
        self.date = Date()
        self.rating = rating
        self.entryTitle = title
        self.body = body
        self.photoData = photo?.jpegData(compressionQuality: 1.0)
        self.latitude = latitude
        self.longitude = longitude
    }
    
    // MARK: - MKAnnotation
    var coordinate: CLLocationCoordinate2D {
        guard let latitude, let longitude else {
            return CLLocationCoordinate2D()
        }
        return CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
    }
    
    var title: String? {
        date.formatted(
            .dateTime.day().month().year()
        )
    }
    
    var subtitle: String? {
        entryTitle
    }
}
