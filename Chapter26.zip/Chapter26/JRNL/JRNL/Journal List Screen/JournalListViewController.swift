//
//  ViewController.swift
//  JRNL
//
//  Created by ios26programming on 03/11/2025.
//

import UIKit

class JournalListViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {
    
    // MARK: - Properties
    @IBOutlet var collectionView: UICollectionView!
    
    private let search = UISearchController(searchResultsController: nil)
    private var filteredTableData: [JournalEntry] = []
    
    // MARK: - View controller lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        tabBarController?.tabBarMinimizeBehavior = .onScrollDown
        setupCollectionView()
        search.searchResultsUpdater = self
        search.obscuresBackgroundDuringPresentation = false
        search.searchBar.placeholder = "Search titles"
        navigationItem.searchController = search
        updateSubtitleCount()
    }
    
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        collectionView.collectionViewLayout.invalidateLayout()
    }
    
    // MARK: - UICollectionViewDataSource
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if search.isActive {
            return filteredTableData.count
        } else {
            return SharedData.shared.numberOfJournalEntries
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let journalCell = collectionView.dequeueReusableCell(withReuseIdentifier: "journalCell", for: indexPath) as! JournalListCollectionViewCell
        let journalEntry: JournalEntry
        if search.isActive {
            journalEntry = filteredTableData[indexPath.item]
        } else {
            journalEntry = SharedData.shared.journalEntry(at: indexPath.item)
        }
        if let photoData = journalEntry.photoData {
            journalCell.photoImageView.image = UIImage(data: photoData)
        } else {
            journalCell.photoImageView.image = nil
        }
        journalCell.dateLabel.text = journalEntry.date.formatted(
            .dateTime.month().day().year()
        )
        journalCell.titleLabel.text = journalEntry.entryTitle
        return journalCell
    }
    
    // MARK: - UICollectionView delete method
    func collectionView(_ collectionView: UICollectionView, contextMenuConfigurationForItemsAt indexPaths: [IndexPath], point: CGPoint) -> UIContextMenuConfiguration? {
        guard let indexPath = indexPaths.first else {
            return nil
        }
        let config = UIContextMenuConfiguration(previewProvider: nil)
        { elements -> UIMenu? in
            let delete = UIAction(title: "Delete") {
                action in
                if self.search.isActive {
                    let selectedJournalEntry = self.filteredTableData[indexPath.item]
                    self.filteredTableData.remove(at: indexPath.item)
                    SharedData.shared.removeSelectedJournalEntry(selectedJournalEntry)
                } else {
                    SharedData.shared.removeJournalEntry(at: indexPath.item)
                }
                collectionView.reloadData()
                self.updateSubtitleCount()
            }
            return UIMenu(children: [delete])
        }
        return config
    }
    
    // MARK: - Navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        super.prepare(for: segue, sender: sender)
        guard segue.identifier == "entryDetail" else {
            return
        }
        guard let journalEntryDetailViewController = segue.destination as? JournalEntryDetailViewController, let indexPath = collectionView.indexPathsForSelectedItems?.first else {
            fatalError("Could not get indexPath")
        }
        let selectedJournalEntry: JournalEntry
        if search.isActive {
            selectedJournalEntry = filteredTableData[indexPath.row]
        } else {
            selectedJournalEntry = SharedData.shared.journalEntry(at: indexPath.row)
        }
        journalEntryDetailViewController.selectedJournalEntry = selectedJournalEntry
    }
    
    // MARK: - Methods
    @IBAction func unwindNewEntryCancel(segue: UIStoryboardSegue) {
    }
    
    @IBAction func unwindNewEntrySave(segue: UIStoryboardSegue) {
        if let sourceViewController = segue.source as? AddJournalEntryViewController, let newJournalEntry = sourceViewController.newJournalEntry {
            SharedData.shared.addJournalEntry(newJournalEntry)
            collectionView.reloadData()
            updateSubtitleCount()
        }
    }
    
    func setupCollectionView() {
        let flowLayout = UICollectionViewFlowLayout()
        flowLayout.sectionInset = UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10)
        flowLayout.minimumInteritemSpacing = 0
        flowLayout.minimumLineSpacing = 10
        collectionView.collectionViewLayout = flowLayout
    }
    
    func updateSubtitleCount() {
        let noOfJournalEntries = SharedData.shared.numberOfJournalEntries
        switch noOfJournalEntries {
        case 0:
            navigationItem.subtitle = "No journal entries"
        case 1:
            navigationItem.subtitle = "1 journal entry"
        default:
            navigationItem.subtitle = "\(noOfJournalEntries) journal entries"
        }
    }
    
    // MARK: - UICollectionViewDelegateFlowLayout
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let numberOfColumns: CGFloat = traitCollection.horizontalSizeClass == .compact ? 1 : 2
        let viewWidth = collectionView.frame.width
        let inset = 10.0
        let contentWidth = viewWidth - inset * (numberOfColumns + 1)
        let cellWidth = contentWidth / numberOfColumns
        let cellHeight = 90.0
        return CGSize(width: cellWidth, height: cellHeight)
    }
}

extension JournalListViewController: UISearchResultsUpdating {
    // MARK: - Search
    func updateSearchResults(for searchController: UISearchController) {
        guard let searchBarText = searchController.searchBar.text else { return }
        filteredTableData = SharedData.shared.allJournalEntries.filter {
            entry in
            entry.entryTitle.lowercased().contains(searchBarText.lowercased())
        }
        collectionView.reloadData()
    }
}
