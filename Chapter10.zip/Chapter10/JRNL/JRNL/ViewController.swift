//
//  ViewController.swift
//  JRNL
//
//  Created by iOS 27 Programming For Beginners on 03/07/2026.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

