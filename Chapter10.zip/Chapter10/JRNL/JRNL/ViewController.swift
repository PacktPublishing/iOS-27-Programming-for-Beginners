//
//  ViewController.swift
//  JRNL
//
//  Created by iOS27ProgrammingForBeginners on 07/07/2026.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

