//
//  ViewController.swift
//  JRNL
//
//  Created by iOS 27 Programming For Beginners on 13/06/2026.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

