//
//  JournalListTableViewCell.swift
//  JRNL
//
//  Created by iOS 27 Programming on 24/09/2026.
//

import UIKit

class JournalListTableViewCell: UITableViewCell {
    // MARK: - Properties
    @IBOutlet var photoImageView: UIImageView!
    @IBOutlet var dateLabel: UILabel!
    @IBOutlet var titleLabel: UILabel!

}
