//
//  SharedData.swift
//  JRNL
//
//  Created by iOS 27 Programming on 29/09/2026.
//

import Foundation

@MainActor class SharedData {
    
    // MARK: - Properties
    static let shared = SharedData()
    private var journalEntries: [JournalEntry] = []
    
    var numberOfJournalEntries: Int {
        journalEntries.count
    }
    
    var allJournalEntries: [JournalEntry] {
        journalEntries
    }
    
    // MARK: - Initialization
    private init() {
        loadJournalEntriesData()
    }
    
    // MARK: - Access methods
    func journalEntry(at index: Int) -> JournalEntry {
        journalEntries[index]
    }
    
    func addJournalEntry(_ newJournalEntry: JournalEntry) {
        journalEntries.insert(newJournalEntry, at: 0)
        saveJournalEntriesData()
    }
    
    func removeJournalEntry(at index: Int) {
        journalEntries.remove(at: index)
        saveJournalEntriesData()
    }
    
    // MARK: - Persistence
    private var savedDataURL: URL {
        URL.documentsDirectory.appending(path: "journalEntriesData.json")
    }
    
    public func loadJournalEntriesData() {
        do {
            let data = try Data(contentsOf: savedDataURL)
            let entries = try JSONDecoder().decode([JournalEntry].self, from: data)
            journalEntries = entries
        } catch {
            print("Failed to read JSON data: \(error.localizedDescription)")
        }
    }
    
    private func saveJournalEntriesData() {
        do {
            let json = try JSONEncoder().encode(journalEntries)
            try json.write(to: savedDataURL)
        } catch {
            print("Failed to write JSON data: \(error.localizedDescription)")
        }
    }
}
