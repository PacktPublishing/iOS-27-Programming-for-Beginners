//
//  AddJournalEntryViewController.swift
//  JRNL
//
//  Created by iOS 27 Programming on 25/09/2026.
//

import UIKit
import CoreLocation

class AddJournalEntryViewController: UIViewController {
    
    // MARK: - Properties
    @IBOutlet var titleTextField: UITextField!
    @IBOutlet var bodyTextView: UITextView!
    @IBOutlet var photoImageView: UIImageView!
    @IBOutlet var saveButton: UIBarButtonItem!
    @IBOutlet var getLocationSwitch: UISwitch!
    @IBOutlet var getLocationSwitchLabel: UILabel!
    
    var newJournalEntry: JournalEntry?
    private let locationManager = CLLocationManager()
    private var locationTask: Task<Void, Error>?
    private var currentLocation: CLLocation?

    override func viewDidLoad() {
        super.viewDidLoad()
        titleTextField.delegate = self
        bodyTextView.delegate = self
        titleTextField.addTarget(self, action: #selector(textFieldDidChange), for: .editingChanged)
        updateSaveButtonState()
    }
    
    // MARK: - Navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let title = titleTextField.text ?? ""
        let body = bodyTextView.text ?? ""
        let photo = photoImageView.image
        let rating = 3
        let lat = currentLocation?.coordinate.latitude
        let long = currentLocation?.coordinate.longitude
        newJournalEntry = JournalEntry(rating: rating, title: title, body: body, photo: photo, latitude: lat, longitude: long)
    }
    
    // MARK: - Actions
    @IBAction func locationSwitchValueChanged(_ sender: UISwitch) {
        if getLocationSwitch.isOn {
            getLocationSwitchLabel.text = "Getting Location..."
            fetchUserLocation()
        } else {
            currentLocation = nil
            getLocationSwitchLabel.text = "Get Location"
            locationTask?.cancel()
        }
    }

}

extension AddJournalEntryViewController: UITextFieldDelegate, UITextViewDelegate {
    
    // MARK: - UITextFieldDelegate
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        updateSaveButtonState()
    }
    
    // MARK: - UITextViewDelegate
    func textView(_ textView: UITextView, shouldChangeTextInRanges ranges: [NSValue], replacementText text: String) -> Bool {
        if (text == "\n") {
            textView.resignFirstResponder()
        }
        return true
    }
    
    func textViewDidChange(_ textView: UITextView) {
        updateSaveButtonState()
    }
    
    func textViewDidEndEditing(_ textView: UITextView) {
        updateSaveButtonState()
    }
    
    // MARK: - Private methods
    private func updateSaveButtonState() {
        let textFieldText = titleTextField.text ?? ""
        let textViewText = bodyTextView.text ?? ""
        let textIsValid = !textFieldText.isEmpty && !textViewText.isEmpty
        if getLocationSwitch.isOn {
            saveButton.isEnabled = textIsValid && currentLocation != nil
        } else {
            saveButton.isEnabled = textIsValid
        }
    }
    
    @objc private func textFieldDidChange(_ sender: UITextField) {
        updateSaveButtonState()
    }
}

extension AddJournalEntryViewController {
    // MARK: - CoreLocation
    private func fetchUserLocation() {
        locationManager.requestWhenInUseAuthorization()
        locationTask = Task {
            for try await update in CLLocationUpdate.liveUpdates() {
                if let location = update.location {
                    updateCurrentLocation(location)
                } else if update.authorizationDenied {
                    failedToGetLocation(message: "Check Location Services settings for JRNL in Settings > Privacy & Security.")
                } else if update.locationUnavailable {
                    failedToGetLocation(message: "Location Unavailable.")
                }
            }
        }
    }
    
    private func updateCurrentLocation(_ location: CLLocation) {
        let interval = location.timestamp.timeIntervalSinceNow
        if abs(interval) < 30 {
            locationTask?.cancel()
            getLocationSwitchLabel.text = "Done"
            let lat = location.coordinate.latitude
            let long = location.coordinate.longitude
            currentLocation = CLLocation(latitude: lat, longitude: long)
            updateSaveButtonState()
        }
    }
    
    private func failedToGetLocation(message: String) {
        locationTask?.cancel()
        getLocationSwitch.setOn(false, animated: true)
        getLocationSwitchLabel.text = "Get Location"
        let alertController = UIAlertController(title: "Failed to get location", message: message, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default)
        alertController.addAction(okAction)
        present(alertController, animated: true)
    }
}
