//
//  JournalListTableViewCell.swift
//  JRNL
//
//  Created by iOS27Programming on 07/11/2026.
//

import UIKit

class JournalListTableViewCell: UITableViewCell {
    // MARK: - Properties
    @IBOutlet var photoImageView: UIImageView!
    @IBOutlet var dateLabel: UILabel!
    @IBOutlet var titleLabel: UILabel!

}
