//
//  JournalEntryDetailTableViewController.swift
//  JRNL
//
//  Created by iOS27Programming on 12/11/2026.
//

import UIKit
import MapKit

class JournalEntryDetailViewController: UITableViewController {
    
    // MARK: - Properties
    @IBOutlet var dateLabel: UILabel!
    @IBOutlet var titleLabel: UILabel!
    @IBOutlet var bodyTextView: UITextView!
    @IBOutlet var photoImageView: UIImageView!
    @IBOutlet var mapImageView: UIImageView!
    
    var selectedJournalEntry: JournalEntry?

    override func viewDidLoad() {
        super.viewDidLoad()
        dateLabel.text = selectedJournalEntry?.date.formatted(
            .dateTime.day().month(.wide).year()
        )
        titleLabel.text = selectedJournalEntry?.entryTitle
        bodyTextView.text = selectedJournalEntry?.body
        photoImageView.image = selectedJournalEntry?.photo
        getMapSnapshot()

    }
    
    // MARK: - Private methods
    private func getMapSnapshot() {
        guard let lat = selectedJournalEntry?.latitude, let long = selectedJournalEntry?.longitude else {
            mapImageView.image = nil
            return
        }
        let options = MKMapSnapshotter.Options()
        options.region = MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: lat, longitude: long), span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.02))
        options.size = CGSize(width: 300, height: 300)
        options.preferredConfiguration = MKStandardMapConfiguration()
        let snapshotter = MKMapSnapshotter(options: options)
        snapshotter.start { snapshot, error in
            if let snapshot {
                self.mapImageView.image = snapshot.image
            } else if let error {
                print("snapshot error: \(error.localizedDescription)")
            }
        }
    }

}
