//
//  ViewController.swift
//  JRNL
//
//  Created by iOS27Programming on 14/11/2026.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

