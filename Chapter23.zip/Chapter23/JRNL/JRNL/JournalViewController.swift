//  JournalViewController.swift
//  JRNL
//
//  Created by Assistant on 13/07/2026.
//

import UIKit

class JournalViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.title = "Journal"
        view.backgroundColor = .systemBackground
        let label = UILabel()
        label.text = "Journal"
        label.font = UIFont.systemFont(ofSize: 32, weight: .bold)
        label.textAlignment = .center
        label.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(label)
        NSLayoutConstraint.activate([
            label.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            label.centerYAnchor.constraint(equalTo: view.centerYAnchor)
        ])
    }
}
