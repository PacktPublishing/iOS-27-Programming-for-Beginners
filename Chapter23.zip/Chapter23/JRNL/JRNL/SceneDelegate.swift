//
//  SceneDelegate.swift
//  JRNL
//
//  Created by iOS 27 Programming on 08/10/2026.
//

import UIKit
import ObjectiveC
import MapKit

private var journalDataSourceKey: UInt8 = 0

class SceneDelegate: UIResponder, UIWindowSceneDelegate {

    var window: UIWindow?


    func scene(_ scene: UIScene, willConnectTo session: UISceneSession, options connectionOptions: UIScene.ConnectionOptions) {
        guard let windowScene = scene as? UIWindowScene else { return }

        let window = UIWindow(windowScene: windowScene)

        // Journal tab using UITableViewController
        let journalTableVC = UITableViewController(style: .insetGrouped)
        journalTableVC.title = "Journal"
        let journalItems = ["Good", "Bad", "OK"]
        // Register a basic cell
        journalTableVC.tableView.register(UITableViewCell.self, forCellReuseIdentifier: "Cell")
        // Provide data source via an object tied to the controller's lifecycle
        final class JournalDataSource: NSObject, UITableViewDataSource {
            let items: [String]
            init(items: [String]) { self.items = items }
            func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int { items.count }
            func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
                let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
                cell.textLabel?.text = items[indexPath.row]
                return cell
            }
        }
        let journalDS = JournalDataSource(items: journalItems)
        journalTableVC.tableView.dataSource = journalDS
        // Associate the data source with the controller so it stays retained
        objc_setAssociatedObject(journalTableVC, &journalDataSourceKey, journalDS, .OBJC_ASSOCIATION_RETAIN_NONATOMIC)

        let journalNav = UINavigationController(rootViewController: journalTableVC)
        journalNav.tabBarItem = UITabBarItem(title: "Journal", image: UIImage(systemName: "person.fill"), selectedImage: UIImage(systemName: "person.fill"))

        // Map tab with MKMapView
        let mapVC = UIViewController()
        mapVC.view.backgroundColor = .systemBackground
        mapVC.title = "Map"

        let mapView = MKMapView()
        mapView.translatesAutoresizingMaskIntoConstraints = false
        mapVC.view.addSubview(mapView)
        NSLayoutConstraint.activate([
            mapView.topAnchor.constraint(equalTo: mapVC.view.topAnchor),
            mapView.bottomAnchor.constraint(equalTo: mapVC.view.bottomAnchor),
            mapView.leadingAnchor.constraint(equalTo: mapVC.view.leadingAnchor),
            mapView.trailingAnchor.constraint(equalTo: mapVC.view.trailingAnchor)
        ])

        let mapNav = UINavigationController(rootViewController: mapVC)
        mapNav.tabBarItem = UITabBarItem(title: "Map", image: UIImage(systemName: "map"), selectedImage: UIImage(systemName: "map"))

        let tabBarController = UITabBarController()
        tabBarController.viewControllers = [journalNav, mapNav]

        window.rootViewController = tabBarController
        self.window = window
        window.makeKeyAndVisible()
    }

    func sceneDidDisconnect(_ scene: UIScene) {
        // Called as the scene is being released by the system.
        // This occurs shortly after the scene enters the background, or when its session is discarded.
        // Release any resources associated with this scene that can be re-created the next time the scene connects.
        // The scene may re-connect later, as its session was not necessarily discarded (see `application:didDiscardSceneSessions` instead).
    }

    func sceneDidBecomeActive(_ scene: UIScene) {
        // Called when the scene has moved from an inactive state to an active state.
        // Use this method to restart any tasks that were paused (or not yet started) when the scene was inactive.
    }

    func sceneWillResignActive(_ scene: UIScene) {
        // Called when the scene will move from an active state to an inactive state.
        // This may occur due to temporary interruptions (ex. an incoming phone call).
    }

    func sceneWillEnterForeground(_ scene: UIScene) {
        // Called as the scene transitions from the background to the foreground.
        // Use this method to undo the changes made on entering the background.
    }

    func sceneDidEnterBackground(_ scene: UIScene) {
        // Called as the scene transitions from the foreground to the background.
        // Use this method to save data, release shared resources, and store enough scene-specific state information
        // to restore the scene back to its current state.
    }


}
