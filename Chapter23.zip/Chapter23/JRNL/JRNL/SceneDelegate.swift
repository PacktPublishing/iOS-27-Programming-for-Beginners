//
//  SceneDelegate.swift
//  JRNL
//
//  Created by iOS27ProgrammingForBeginners on 13/07/2026.
//

import UIKit

class SceneDelegate: UIResponder, UIWindowSceneDelegate {

    var window: UIWindow?


    func scene(_ scene: UIScene, willConnectTo session: UISceneSession, options connectionOptions: UIScene.ConnectionOptions) {
        // Create the tab view controllers
        let journalVC = JournalViewController()
        let mapVC = MapViewController()
        
        let journalNav = UINavigationController(rootViewController: journalVC)
        let mapNav = UINavigationController(rootViewController: mapVC)
        
        journalNav.tabBarItem = UITabBarItem(title: "Journal", image: UIImage(systemName: "person.fill"), tag: 0)
        mapNav.tabBarItem = UITabBarItem(title: "Map", image: UIImage(systemName: "map"), tag: 1)

        let tabBarController = UITabBarController()
        tabBarController.viewControllers = [journalNav, mapNav]

        // Set the tab bar controller as the root
        if let windowScene = scene as? UIWindowScene {
            let window = UIWindow(windowScene: windowScene)
            window.rootViewController = tabBarController
            self.window = window
            window.makeKeyAndVisible()
        }
    }

    func sceneDidDisconnect(_ scene: UIScene) {
        // Called as the scene is being released by the system.
        // This occurs shortly after the scene enters the background, or when its session is discarded.
        // Release any resources associated with this scene that can be re-created the next time the scene connects.
        // The scene may re-connect later, as its session was not necessarily discarded (see `application:didDiscardSceneSessions` instead).
    }

    func sceneDidBecomeActive(_ scene: UIScene) {
        // Called when the scene has moved from an inactive state to an active state.
        // Use this method to restart any tasks that were paused (or not yet started) when the scene was inactive.
    }

    func sceneWillResignActive(_ scene: UIScene) {
        // Called when the scene will move from an active state to an inactive state.
        // This may occur due to temporary interruptions (ex. an incoming phone call).
    }

    func sceneWillEnterForeground(_ scene: UIScene) {
        // Called as the scene transitions from the background to the foreground.
        // Use this method to undo the changes made on entering the background.
    }

    func sceneDidEnterBackground(_ scene: UIScene) {
        // Called as the scene transitions from the foreground to the background.
        // Use this method to save data, release shared resources, and store enough scene-specific state information
        // to restore the scene back to its current state.
    }


}

