//
//  JournalEntry.swift
//  JRNL
//
//  Created by iOS 27 Programming on 08/10/2026.
//

import UIKit

// This file contains the definition of the JournalEntry structure, which can store a number representing a rating, a string representing a journal title, a string representing journal body text, a UIImage to store an image, and a CLLocationCoordinate2D to store a map location. This file also contains a sampleData structure which contains 3 sample journal entries.

struct JournalEntry: Identifiable {
    var id: UUID
    var rating: Int
    var title: String
    var body: String
    var image: UIImage?
    var location: CLLocationCoordinate2D?
}

struct sampleData {
    static let entries: [JournalEntry] = [
        JournalEntry(id: UUID(), rating: 5, title: "Today", body: "Today was great!", image: nil, location: nil),
        JournalEntry(id: UUID(), rating: 3, title: "Yesterday", body: "Yesterday was okay.", image: nil, location: nil)
    ]
}
