//
//  JournalListTableViewCell.swift
//  JRNL
//
//  Created by iOS27ProgrammingForBeginners on 11/09/2026.
//

import UIKit

class JournalListTableViewCell: UITableViewCell {
    // MARK: - Properties
    @IBOutlet var photoImageView: UIImageView!
    @IBOutlet var dateLabel: UILabel!
    @IBOutlet var titleLabel: UILabel!
}
